public interface ITributacao {
    public double calcImposto();
}
