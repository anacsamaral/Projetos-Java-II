public interface IItem {
    String getInfo();
    double calcularMulta(int diasAtraso);
}