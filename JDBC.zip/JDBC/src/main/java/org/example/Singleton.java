package org.example;

public class Singleton {
}
